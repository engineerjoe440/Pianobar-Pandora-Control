# Pianobar-Pandora-Control
A Python-Based SSH secured control system for Pianobar running on a separate device.
